<h1 align="center">chrome-extension-react-demo</h1>
<div align="center">
基于react开发的Chrome插件demo。
</div>

## ✨ 特性

- 🌈 完整案例展示。
- 📦 使用React组件进行页面的开发。
- 🌍 中英文两种语言支持。

## 介绍文档

[文档](https://www.jianshu.com/p/257c8cae2099)

## ⌨️ 本地开发

```bash
$ git clone https://github.com/hepengwei/chrome-extension-react-demo.git
$ cd chrome-extension-react-demo
$ npm install
$ npm run build
```
