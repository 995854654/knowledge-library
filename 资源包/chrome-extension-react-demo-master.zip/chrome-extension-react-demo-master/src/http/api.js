export const loginUrl = "user/login";

export const addLogUrl = 'logs/addLog';
export const deleteLogUrl = "logs/deleteLog"
